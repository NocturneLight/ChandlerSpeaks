package com.ChandlerSpeaks;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Document;

import java.util.ArrayList;

public class GrantSearchResultsActivity extends AppCompatActivity implements GrantRecyclerAdapter.OnGrantClickListener {

    private ArrayList<Grant> grantList = new ArrayList<>();
    private ArrayList<FilterItem> filterList = new ArrayList<>();
    private String keywords;
    private int date[];
    Document document;
    private RecyclerView recyclerView;
    private GrantRecyclerAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grant_search_results);

        Intent intent = getIntent();
        Bundle bundle = intent.getBundleExtra("bundle");
        filterList = (ArrayList<FilterItem>) bundle.getSerializable("filterList");
        keywords = bundle.getString("keywords");
        date = bundle.getIntArray("date");

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        actionBar.setCustomView(R.layout.action_bar_layout);
        actionBar.setDisplayHomeAsUpEnabled(true);

        ConvertRSSFeedData convertFeed = (ConvertRSSFeedData) new ConvertRSSFeedData(new ConvertRSSFeedData.AsyncOutput() {
            @Override
            public void retrieveGrantList(Document doc) {
                document = doc;
                ProcessRSSFeedData processFeed = new ProcessRSSFeedData();
                grantList = processFeed.processData(document, filterList, keywords, date);
                if(grantList.size() > 0)
                {
                    refreshView();
                }
                else
                {
                    displayNoResults();
                }

            }
        }).execute();
    }

    @Override
    public void onItemClick(int position)
    {
        //Toast.makeText(MainActivity.this, "hi", Toast.LENGTH_LONG).show();
        Intent intent = new Intent(GrantSearchResultsActivity.this, GrantActivity.class);
        Bundle bundle = new Bundle();
        bundle.putSerializable("grant", grantList.get(position));
        intent.putExtra("bundle", bundle);
        startActivity(intent);
    }

    private void refreshView()
    {
        recyclerView = findViewById(R.id.recyclerView);
        //recyclerView.setHasFixedSize(true);
        layoutManager = new LinearLayoutManager(GrantSearchResultsActivity.this);
        adapter = new GrantRecyclerAdapter(grantList, GrantSearchResultsActivity.this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        Toast.makeText(this, Integer.toString(grantList.size()) + " results found", Toast.LENGTH_SHORT).show();
    }

    private void displayNoResults()
    {
        recyclerView = findViewById(R.id.recyclerView);
        textView = findViewById(R.id.noResults);

        recyclerView.setVisibility(View.INVISIBLE);
        textView.setVisibility(View.VISIBLE);
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        finish();
        return false;
    }
}
